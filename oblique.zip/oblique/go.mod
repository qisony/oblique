module oblique

go 1.22

require (
	golang.org/x/crypto v0.29.0
	golang.org/x/net v0.31.0
)
