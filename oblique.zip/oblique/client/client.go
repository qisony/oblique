package client

import (
	"context"
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/net/http2"

	"oblique/protocol"
)

type Config struct {
	ServerAddr       string  `json:"server_addr"`        // "your-domain.com:443" или "your-domain.com:8443"
	ServerName       string  `json:"server_name"`        // SNI, например "your-domain.com"
	DownPath         string  `json:"down_path"`          // "/api/v2/events"
	UpPath           string  `json:"up_path"`            // "/api/v2/telemetry"
	CookieName       string  `json:"cookie_name"`        // "_sid"
	ServerPublicKey  string  `json:"server_public_key"`  // base64url X25519
	PSK              string  `json:"psk"`                // base64url 32B
	UseTLSExporter   bool    `json:"use_tls_exporter"`   // true для прямого TLS, false за Nginx/CDN
	InsecureSkipTLS  bool    `json:"insecure_skip_tls"`  // false в проде!
	PaddingBeta      float64 `json:"padding_beta"`       // 0.15 - 0.25
	RotateBytes      int64   `json:"rotate_bytes"`       // ротация носителя (напр. 25000000 = 25 МБ)
	RotateSeconds    int     `json:"rotate_seconds"`     // ротация по времени (напр. 180 сек)
	SocksListen      string  `json:"socks_listen"`       // "127.0.0.1:10808"
	SocksUser        string  `json:"socks_user"`         // логин локального SOCKS5 (рекомендуется)
	SocksPass        string  `json:"socks_pass"`         // пароль локального SOCKS5
}

type Client struct {
	cfg        Config
	serverPub  []byte
	psk        []byte
	sessionID  [16]byte
	sessionSeed [32]byte
	shaper     *protocol.Shaper

	nextStreamID atomic.Uint32
	upGen        atomic.Uint32
	downGen      atomic.Uint32

	upCh    chan []byte
	mu      sync.Mutex
	streams map[uint32]net.Conn
}

func New(cfg Config) (*Client, error) {
	if cfg.CookieName == "" {
		cfg.CookieName = "_sid"
	}
	if cfg.RotateBytes <= 0 {
		cfg.RotateBytes = 25 * 1024 * 1024
	}
	if cfg.RotateSeconds <= 0 {
		cfg.RotateSeconds = 180
	}
	pub, err := base64.RawURLEncoding.DecodeString(cfg.ServerPublicKey)
	if err != nil || len(pub) != 32 {
		return nil, errors.New("invalid server_public_key")
	}
	psk, err := base64.RawURLEncoding.DecodeString(cfg.PSK)
	if err != nil || len(psk) != 32 {
		return nil, errors.New("invalid psk")
	}
	c := &Client{
		cfg:       cfg,
		serverPub: pub,
		psk:       psk,
		shaper:    protocol.NewShaper(cfg.PaddingBeta),
		upCh:      make(chan []byte, 512),
		streams:   make(map[uint32]net.Conn),
	}
	_, _ = rand.Read(c.sessionID[:])
	_, _ = rand.Read(c.sessionSeed[:])
	return c, nil
}

func (c *Client) dialTLS() (*tls.Conn, []byte, error) {
	dialer := &net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second}
	tlsCfg := &tls.Config{
		ServerName:         c.cfg.ServerName,
		MinVersion:         tls.VersionTLS13,
		NextProtos:         []string{"h2", "http/1.1"},
		InsecureSkipVerify: c.cfg.InsecureSkipTLS,
	}
	conn, err := tls.DialWithDialer(dialer, "tcp", c.cfg.ServerAddr, tlsCfg)
	if err != nil {
		return nil, nil, err
	}
	var binding []byte
	if c.cfg.UseTLSExporter {
		st := conn.ConnectionState()
		binding, err = protocol.ExportTLSBinding(&st)
		if err != nil {
			_ = conn.Close()
			return nil, nil, err
		}
	}
	return conn, binding, nil
}

func (c *Client) makeSingleConnHTTPClient(tlsConn *tls.Conn) *http.Client {
	used := false
	tr := &http.Transport{
		DialTLSContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			if used {
				return nil, errors.New("single-use carrier transport exhausted")
			}
			used = true
			return tlsConn, nil
		},
		ForceAttemptHTTP2: true,
	}
	_ = http2.ConfigureTransport(tr)
	return &http.Client{Transport: tr}
}

func (c *Client) buildToken(dir byte, gen uint32, method, path string, binding []byte) (string, error) {
	var nonce [12]byte
	_, _ = rand.Read(nonce[:])
	ap := protocol.AuthPayload{
		Timestamp:   time.Now().Unix(),
		AuthNonce:   nonce,
		SessionID:   c.sessionID,
		SessionSeed: c.sessionSeed,
		Direction:   dir,
		CarrierGen:  gen,
	}
	aad := []byte(method + ":" + path)
	return protocol.SealAuthToken(c.serverPub, c.psk, binding, ap, aad)
}

func (c *Client) setBrowserHeaders(req *http.Request, token string) {
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("Cookie", c.cfg.CookieName+"="+token)
}

// downlinkLoop поддерживает активный GET-носитель и ротирует его без обрыва сессии.
func (c *Client) downlinkLoop() {
	backoff := time.Second
	for {
		gen := c.downGen.Add(1)
		err := c.runSingleDownlink(gen)
		if err != nil {
			log.Printf("[client] downlink gen=%d closed: %v", gen, err)
			time.Sleep(backoff)
			if backoff < 8*time.Second {
				backoff *= 2
			}
		} else {
			backoff = time.Second
		}
	}
}

func (c *Client) runSingleDownlink(gen uint32) error {
	tlsConn, binding, err := c.dialTLS()
	if err != nil {
		return err
	}
	defer tlsConn.Close()

	token, err := c.buildToken(protocol.DirDownlink, gen, http.MethodGet, c.cfg.DownPath, binding)
	if err != nil {
		return err
	}
	cipher, err := protocol.NewRecordCipher(c.sessionSeed, c.sessionID, protocol.DirDownlink, gen)
	if err != nil {
		return err
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(c.cfg.RotateSeconds)*time.Second)
	defer cancel()

	urlStr := fmt.Sprintf("https://%s%s", c.cfg.ServerName, c.cfg.DownPath)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, urlStr, nil)
	if err != nil {
		return err
	}
	c.setBrowserHeaders(req, token)

	httpClient := c.makeSingleConnHTTPClient(tlsConn)
	resp, err := httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("unexpected status %d", resp.StatusCode)
	}

	log.Printf("[client] downlink connected gen=%d proto=%s", gen, resp.Proto)

	var bytesRead int64
	for {
		_, plain, err := cipher.ReadRecord(resp.Body)
		if err != nil {
			if errors.Is(ctx.Err(), context.DeadlineExceeded) {
				return nil // плановая ротация по времени
			}
			return err
		}
		bytesRead += int64(len(plain))
		frames, err := protocol.DecodeFrames(plain)
		if err != nil {
			return err
		}
		for _, f := range frames {
			switch f.Type {
			case protocol.FrameData:
				c.mu.Lock()
				conn := c.streams[f.StreamID]
				c.mu.Unlock()
				if conn != nil {
					_ = conn.SetWriteDeadline(time.Now().Add(15 * time.Second))
					if _, werr := conn.Write(f.Payload); werr != nil {
						c.closeStream(f.StreamID, true)
					}
				}
			case protocol.FrameClose:
				c.closeStream(f.StreamID, false)
			case protocol.FramePing:
				// канал жив
			}
		}
		if bytesRead >= c.cfg.RotateBytes {
			return nil // плановая ротация по объему
		}
	}
}

// uplinkLoop поддерживает потоковый POST-носитель с плановой ротацией и защитой от обрыва.
func (c *Client) uplinkLoop() {
	backoff := time.Second
	for {
		gen := c.upGen.Add(1)
		err := c.runSingleUplink(gen)
		if err != nil {
			log.Printf("[client] uplink gen=%d closed: %v", gen, err)
			time.Sleep(backoff)
			if backoff < 8*time.Second {
				backoff *= 2
			}
		} else {
			backoff = time.Second
		}
	}
}

func (c *Client) runSingleUplink(gen uint32) error {
	tlsConn, binding, err := c.dialTLS()
	if err != nil {
		return err
	}
	defer tlsConn.Close()

	token, err := c.buildToken(protocol.DirUplink, gen, http.MethodPost, c.cfg.UpPath, binding)
	if err != nil {
		return err
	}
	cipher, err := protocol.NewRecordCipher(c.sessionSeed, c.sessionID, protocol.DirUplink, gen)
	if err != nil {
		return err
	}

	pr, pw := io.Pipe()
	urlStr := fmt.Sprintf("https://%s%s", c.cfg.ServerName, c.cfg.UpPath)
	req, err := http.NewRequest(http.MethodPost, urlStr, pr)
	if err != nil {
		return err
	}
	c.setBrowserHeaders(req, token)
	req.Header.Set("Content-Type", "application/octet-stream")

	httpClient := c.makeSingleConnHTTPClient(tlsConn)
	doneCh := make(chan error, 1)
	go func() {
		resp, err := httpClient.Do(req)
		if err != nil {
			doneCh <- err
			return
		}
		_, _ = io.Copy(io.Discard, resp.Body)
		_ = resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			doneCh <- fmt.Errorf("uplink status %d", resp.StatusCode)
			return
		}
		doneCh <- nil
	}()

	// Проталкиваем стартовый PING, чтобы POST-запрос немедленно дошел до сервера
	initRec := c.shaper.ShapePayload(protocol.EncodeFrame(protocol.Frame{Type: protocol.FramePing}))
	if _, err := cipher.WriteRecord(pw, 0, initRec); err != nil {
		_ = pw.Close()
		return err
	}
	log.Printf("[client] uplink connected gen=%d", gen)

	rotateTimer := time.NewTimer(time.Duration(c.cfg.RotateSeconds) * time.Second)
	defer rotateTimer.Stop()
	pingTicker := time.NewTicker(20 * time.Second)
	defer pingTicker.Stop()

	var bytesWritten int64
	for {
		select {
		case err := <-doneCh:
			_ = pw.Close()
			return err
		case <-rotateTimer.C:
			_ = pw.Close()
			<-doneCh
			return nil
		case <-pingTicker.C:
			shaped := c.shaper.ShapePayload(protocol.EncodeFrame(protocol.Frame{Type: protocol.FramePing}))
			if _, err := cipher.WriteRecord(pw, 0, shaped); err != nil {
				_ = pw.Close()
				return err
			}
		case rawFrame := <-c.upCh:
			batch := rawFrame
			for len(batch) < 12288 {
				select {
				case next := <-c.upCh:
					if len(batch)+len(next) > 24000 {
						shaped := c.shaper.ShapePayload(batch)
						n, err := cipher.WriteRecord(pw, 0, shaped)
						if err != nil {
							_ = pw.Close()
							return err
						}
						bytesWritten += int64(n)
						batch = next
					} else {
						batch = append(batch, next...)
					}
				default:
					goto sendUp
				}
			}
		sendUp:
			shaped := c.shaper.ShapePayload(batch)
			n, err := cipher.WriteRecord(pw, 0, shaped)
			if err != nil {
				_ = pw.Close()
				return err
			}
			bytesWritten += int64(n)
			if bytesWritten >= c.cfg.RotateBytes {
				_ = pw.Close()
				<-doneCh
				return nil
			}
		}
	}
}

func (c *Client) sendFrame(f protocol.Frame) {
	c.upCh <- protocol.EncodeFrame(f)
}

func (c *Client) closeStream(streamID uint32, notifyServer bool) {
	c.mu.Lock()
	conn := c.streams[streamID]
	delete(c.streams, streamID)
	c.mu.Unlock()
	if conn != nil {
		_ = conn.Close()
	}
	if notifyServer {
		c.sendFrame(protocol.Frame{Type: protocol.FrameClose, StreamID: streamID})
	}
}

// Run запускает носители и локальный SOCKS5-сервер.
func (c *Client) Run() error {
	go c.downlinkLoop()
	go c.uplinkLoop()

	ln, err := net.Listen("tcp", c.cfg.SocksListen)
	if err != nil {
		return err
	}
	log.Printf("[client] SOCKS5 listening on %s (auth=%v)", c.cfg.SocksListen, c.cfg.SocksUser != "")
	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go c.handleSocks5(conn)
	}
}

func (c *Client) handleSocks5(conn net.Conn) {
	// 1. Выбор метода аутентификации (RFC 1928)
	var head [2]byte
	if _, err := io.ReadFull(conn, head[:]); err != nil || head[0] != 0x05 {
		_ = conn.Close()
		return
	}
	methods := make([]byte, head[1])
	if _, err := io.ReadFull(conn, methods); err != nil {
		_ = conn.Close()
		return
	}

	requireAuth := c.cfg.SocksUser != ""
	if requireAuth {
		hasUserPass := false
		for _, m := range methods {
			if m == 0x02 {
				hasUserPass = true
				break
			}
		}
		if !hasUserPass {
			_, _ = conn.Write([]byte{0x05, 0xFF})
			_ = conn.Close()
			return
		}
		_, _ = conn.Write([]byte{0x05, 0x02})
		if !c.verifySocksAuth(conn) {
			_ = conn.Close()
			return
		}
	} else {
		_, _ = conn.Write([]byte{0x05, 0x00})
	}

	// 2. Чтение запроса CONNECT
	var req [4]byte
	if _, err := io.ReadFull(conn, req[:]); err != nil || req[0] != 0x05 || req[1] != 0x01 {
		_, _ = conn.Write([]byte{0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		_ = conn.Close()
		return
	}

	var host string
	switch req[3] {
	case 0x01: // IPv4
		var ip [4]byte
		if _, err := io.ReadFull(conn, ip[:]); err != nil {
			_ = conn.Close()
			return
		}
		host = net.IP(ip[:]).String()
	case 0x03: // Domain
		var l [1]byte
		if _, err := io.ReadFull(conn, l[:]); err != nil {
			_ = conn.Close()
			return
		}
		dom := make([]byte, l[0])
		if _, err := io.ReadFull(conn, dom); err != nil {
			_ = conn.Close()
			return
		}
		host = string(dom)
	case 0x04: // IPv6
		var ip [16]byte
		if _, err := io.ReadFull(conn, ip[:]); err != nil {
			_ = conn.Close()
			return
		}
		host = net.IP(ip[:]).String()
	default:
		_, _ = conn.Write([]byte{0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		_ = conn.Close()
		return
	}

	var portBuf [2]byte
	if _, err := io.ReadFull(conn, portBuf[:]); err != nil {
		_ = conn.Close()
		return
	}
	port := binary.BigEndian.Uint16(portBuf[:])
	target := net.JoinHostPort(host, fmt.Sprintf("%d", port))

	streamID := c.nextStreamID.Add(1)
	c.mu.Lock()
	c.streams[streamID] = conn
	c.mu.Unlock()

	c.sendFrame(protocol.Frame{
		Type:     protocol.FrameOpen,
		StreamID: streamID,
		Payload:  []byte(target),
	})

	// Отвечаем успехом SOCKS5
	_, _ = conn.Write([]byte{0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0})

	buf := make([]byte, protocol.MaxFrameData)
	for {
		n, err := conn.Read(buf)
		if n > 0 {
			chunk := make([]byte, n)
			copy(chunk, buf[:n])
			c.sendFrame(protocol.Frame{
				Type:     protocol.FrameData,
				StreamID: streamID,
				Payload:  chunk,
			})
		}
		if err != nil {
			c.closeStream(streamID, true)
			return
		}
	}
}

func (c *Client) verifySocksAuth(conn net.Conn) bool {
	var ver [1]byte
	if _, err := io.ReadFull(conn, ver[:]); err != nil || ver[0] != 0x01 {
		return false
	}
	var ulen [1]byte
	if _, err := io.ReadFull(conn, ulen[:]); err != nil {
		return false
	}
	u := make([]byte, ulen[0])
	if _, err := io.ReadFull(conn, u); err != nil {
		return false
	}
	var plen [1]byte
	if _, err := io.ReadFull(conn, plen[:]); err != nil {
		return false
	}
	p := make([]byte, plen[0])
	if _, err := io.ReadFull(conn, p); err != nil {
		return false
	}
	if string(u) != c.cfg.SocksUser || string(p) != c.cfg.SocksPass {
		_, _ = conn.Write([]byte{0x01, 0x01})
		return false
	}
	_, _ = conn.Write([]byte{0x01, 0x00})
	return true
}
