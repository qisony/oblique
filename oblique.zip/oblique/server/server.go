package server

import (
	"crypto/ecdh"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"io"
	"log"
	"net"
	"net/http"
	"sync"
	"time"

	"golang.org/x/net/http2"

	"oblique/protocol"
)

type Config struct {
	ListenAddr   string  `json:"listen_addr"`   // "127.0.0.1:9443" (за Nginx) или ":8443" (прямой TLS)
	Mode         string  `json:"mode"`          // "http" (за Nginx/Caddy) или "tls" (прямой TLS + TLS-exporter)
	CertFile     string  `json:"cert_file"`     // нужен только для mode="tls"
	KeyFile      string  `json:"key_file"`      // нужен только для mode="tls"
	DownPath     string  `json:"down_path"`     // например "/api/v2/events"
	UpPath       string  `json:"up_path"`       // например "/api/v2/telemetry"
	CookieName   string  `json:"cookie_name"`   // например "_sid"
	PrivateKey   string  `json:"private_key"`   // base64url X25519
	PSK          string  `json:"psk"`           // base64url 32B
	PaddingBeta  float64 `json:"padding_beta"`  // 0.15 - 0.25
	SessionTTL   int     `json:"session_ttl"`   // секунд простоя, по умолчанию 300
}

type Session struct {
	id         [16]byte
	seed       [32]byte
	shaper     *protocol.Shaper
	downCh     chan []byte
	mu         sync.Mutex
	streams    map[uint32]net.Conn
	lastActive time.Time
	closed     bool
}

func newSession(id [16]byte, seed [32]byte, beta float64) *Session {
	return &Session{
		id:         id,
		seed:       seed,
		shaper:     protocol.NewShaper(beta),
		downCh:     make(chan []byte, 256),
		streams:    make(map[uint32]net.Conn),
		lastActive: time.Now(),
	}
}

func (s *Session) touch() {
	s.mu.Lock()
	s.lastActive = time.Now()
	s.mu.Unlock()
}

func (s *Session) enqueue(rawFrame []byte) {
	s.touch()
	select {
	case s.downCh <- rawFrame:
	default:
		// Очередь переполнена при зависшем downlink — ждем до 3 секунд, иначе сбрасываем
		timer := time.NewTimer(3 * time.Second)
		defer timer.Stop()
		select {
		case s.downCh <- rawFrame:
		case <-timer.C:
		}
	}
}

func (s *Session) openStream(streamID uint32, targetAddr string) {
	conn, err := net.DialTimeout("tcp", targetAddr, 10*time.Second)
	if err != nil {
		s.enqueue(protocol.EncodeFrame(protocol.Frame{
			Type:     protocol.FrameClose,
			StreamID: streamID,
		}))
		return
	}

	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		_ = conn.Close()
		return
	}
	s.streams[streamID] = conn
	s.mu.Unlock()

	go func() {
		defer func() {
			s.closeStream(streamID)
			s.enqueue(protocol.EncodeFrame(protocol.Frame{
				Type:     protocol.FrameClose,
				StreamID: streamID,
			}))
		}()
		buf := make([]byte, protocol.MaxFrameData)
		for {
			n, err := conn.Read(buf)
			if n > 0 {
				chunk := make([]byte, n)
				copy(chunk, buf[:n])
				s.enqueue(protocol.EncodeFrame(protocol.Frame{
					Type:     protocol.FrameData,
					StreamID: streamID,
					Payload:  chunk,
				}))
			}
			if err != nil {
				return
			}
		}
	}()
}

func (s *Session) writeStream(streamID uint32, data []byte) {
	s.mu.Lock()
	conn := s.streams[streamID]
	s.mu.Unlock()
	if conn == nil {
		return
	}
	_ = conn.SetWriteDeadline(time.Now().Add(15 * time.Second))
	if _, err := conn.Write(data); err != nil {
		s.closeStream(streamID)
		s.enqueue(protocol.EncodeFrame(protocol.Frame{
			Type:     protocol.FrameClose,
			StreamID: streamID,
		}))
	}
}

func (s *Session) closeStream(streamID uint32) {
	s.mu.Lock()
	conn := s.streams[streamID]
	delete(s.streams, streamID)
	s.mu.Unlock()
	if conn != nil {
		_ = conn.Close()
	}
}

func (s *Session) closeAll() {
	s.mu.Lock()
	s.closed = true
	for id, c := range s.streams {
		_ = c.Close()
		delete(s.streams, id)
	}
	s.mu.Unlock()
}

type Server struct {
	cfg      Config
	privKey  *ecdh.PrivateKey
	psk      []byte
	replay   *protocol.ReplayCache
	mu       sync.Mutex
	sessions map[[16]byte]*Session
}

func New(cfg Config) (*Server, error) {
	if cfg.CookieName == "" {
		cfg.CookieName = "_sid"
	}
	if cfg.SessionTTL <= 0 {
		cfg.SessionTTL = 300
	}
	privBytes, err := base64.RawURLEncoding.DecodeString(cfg.PrivateKey)
	if err != nil {
		return nil, err
	}
	privKey, err := ecdh.X25519().NewPrivateKey(privBytes)
	if err != nil {
		return nil, err
	}
	psk, err := base64.RawURLEncoding.DecodeString(cfg.PSK)
	if err != nil || len(psk) != 32 {
		return nil, errors.New("invalid PSK (must be 32 bytes base64url)")
	}
	s := &Server{
		cfg:      cfg,
		privKey:  privKey,
		psk:      psk,
		replay:   protocol.NewReplayCache(),
		sessions: make(map[[16]byte]*Session),
	}
	go s.gcLoop()
	return s, nil
}

func (s *Server) gcLoop() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	ttl := time.Duration(s.cfg.SessionTTL) * time.Second
	for range ticker.C {
		now := time.Now()
		s.mu.Lock()
		for id, sess := range s.sessions {
			sess.mu.Lock()
			expired := now.Sub(sess.lastActive) > ttl
			sess.mu.Unlock()
			if expired {
				sess.closeAll()
				delete(s.sessions, id)
			}
		}
		s.mu.Unlock()
	}
}

func (s *Server) getOrCreateSession(ap protocol.AuthPayload) (*Session, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.sessions[ap.SessionID]
	if ok {
		if sess.seed != ap.SessionSeed {
			return nil, protocol.ErrAuthFailed
		}
		sess.touch()
		return sess, nil
	}
	sess = newSession(ap.SessionID, ap.SessionSeed, s.cfg.PaddingBeta)
	s.sessions[ap.SessionID] = sess
	return sess, nil
}

func (s *Server) renderCover404(w http.ResponseWriter) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusNotFound)
	_, _ = w.Write([]byte("<html><head><title>404 Not Found</title></head><body><center><h1>404 Not Found</h1></center></body></html>\n"))
}

func (s *Server) authenticate(r *http.Request, expectedDir byte) (protocol.AuthPayload, error) {
	var ap protocol.AuthPayload
	c, err := r.Cookie(s.cfg.CookieName)
	if err != nil || c.Value == "" {
		return ap, protocol.ErrAuthFailed
	}

	var tlsBinding []byte
	if s.cfg.Mode == "tls" && r.TLS != nil {
		tlsBinding, err = protocol.ExportTLSBinding(r.TLS)
		if err != nil {
			return ap, protocol.ErrAuthFailed
		}
	}

	aad := []byte(r.Method + ":" + r.URL.Path)
	ap, err = protocol.OpenAuthToken(c.Value, s.privKey, s.psk, tlsBinding, aad, s.replay)
	if err != nil {
		return ap, err
	}
	if ap.Direction != expectedDir {
		return ap, protocol.ErrAuthFailed
	}
	return ap, nil
}

func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	switch {
	case r.Method == http.MethodGet && r.URL.Path == s.cfg.DownPath:
		s.handleDownlink(w, r)
	case r.Method == http.MethodPost && r.URL.Path == s.cfg.UpPath:
		s.handleUplink(w, r)
	default:
		s.renderCover404(w)
	}
}

func (s *Server) handleDownlink(w http.ResponseWriter, r *http.Request) {
	ap, err := s.authenticate(r, protocol.DirDownlink)
	if err != nil {
		s.renderCover404(w)
		return
	}
	sess, err := s.getOrCreateSession(ap)
	if err != nil {
		s.renderCover404(w)
		return
	}
	cipher, err := protocol.NewRecordCipher(ap.SessionSeed, ap.SessionID, protocol.DirDownlink, ap.CarrierGen)
	if err != nil {
		s.renderCover404(w)
		return
	}

	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Cache-Control", "no-cache, no-store")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	flusher.Flush()

	ctx := r.Context()
	keepalive := time.NewTicker(20 * time.Second)
	defer keepalive.Stop()

	// Первичная запись подтверждения канала
	initPayload := sess.shaper.ShapePayload(protocol.EncodeFrame(protocol.Frame{Type: protocol.FramePing}))
	if _, err := cipher.WriteRecord(w, 0, initPayload); err != nil {
		return
	}
	flusher.Flush()

	log.Printf("[server] downlink connected session=%s gen=%d", hex.EncodeToString(ap.SessionID[:4]), ap.CarrierGen)

	for {
		select {
		case <-ctx.Done():
			return
		case <-keepalive.C:
			payload := sess.shaper.ShapePayload(protocol.EncodeFrame(protocol.Frame{Type: protocol.FramePing}))
			if _, err := cipher.WriteRecord(w, 0, payload); err != nil {
				return
			}
			flusher.Flush()
		case rawFrame := <-sess.downCh:
			// Коалесцинг: добираем готовые фреймы из канала до ~12 КБ за одну запись
			batch := rawFrame
			for len(batch) < 12288 {
				select {
				case next := <-sess.downCh:
					if len(batch)+len(next) > 24000 {
						// Возвращаем обратно не поместившийся фрейм (отправим отдельно)
						shaped := sess.shaper.ShapePayload(batch)
						if _, err := cipher.WriteRecord(w, 0, shaped); err != nil {
							return
						}
						flusher.Flush()
						batch = next
					} else {
						batch = append(batch, next...)
					}
				default:
					goto sendBatch
				}
			}
		sendBatch:
			shaped := sess.shaper.ShapePayload(batch)
			if _, err := cipher.WriteRecord(w, 0, shaped); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}

func (s *Server) handleUplink(w http.ResponseWriter, r *http.Request) {
	ap, err := s.authenticate(r, protocol.DirUplink)
	if err != nil {
		s.renderCover404(w)
		return
	}
	sess, err := s.getOrCreateSession(ap)
	if err != nil {
		s.renderCover404(w)
		return
	}
	cipher, err := protocol.NewRecordCipher(ap.SessionSeed, ap.SessionID, protocol.DirUplink, ap.CarrierGen)
	if err != nil {
		s.renderCover404(w)
		return
	}

	log.Printf("[server] uplink connected session=%s gen=%d", hex.EncodeToString(ap.SessionID[:4]), ap.CarrierGen)

	for {
		_, plain, err := cipher.ReadRecord(r.Body)
		if err != nil {
			if err != io.EOF && !errors.Is(err, io.ErrUnexpectedEOF) {
				log.Printf("[server] uplink read ended session=%s: %v", hex.EncodeToString(ap.SessionID[:4]), err)
			}
			break
		}
		sess.touch()
		frames, err := protocol.DecodeFrames(plain)
		if err != nil {
			break
		}
		for _, f := range frames {
			switch f.Type {
			case protocol.FrameOpen:
				go sess.openStream(f.StreamID, string(f.Payload))
			case protocol.FrameData:
				sess.writeStream(f.StreamID, f.Payload)
			case protocol.FrameClose:
				sess.closeStream(f.StreamID)
			case protocol.FramePing:
				// keepalive принят
			}
		}
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(`{"status":"ok"}`))
}

func (s *Server) Run() error {
	srv := &http.Server{
		Addr:              s.cfg.ListenAddr,
		Handler:           s,
		ReadHeaderTimeout: 15 * time.Second,
	}

	if s.cfg.Mode == "tls" {
		tlsCfg := &tls.Config{
			MinVersion: tls.VersionTLS13,
			NextProtos: []string{"h2", "http/1.1"},
		}
		srv.TLSConfig = tlsCfg
		_ = http2.ConfigureServer(srv, &http2.Server{})
		log.Printf("[server] listening TLS (with TLS-exporter) on %s", s.cfg.ListenAddr)
		return srv.ListenAndServeTLS(s.cfg.CertFile, s.cfg.KeyFile)
	}

	log.Printf("[server] listening local HTTP (behind Nginx/Caddy) on %s", s.cfg.ListenAddr)
	return srv.ListenAndServe()
}
