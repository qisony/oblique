package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"os"

	"oblique/client"
	"oblique/protocol"
	"oblique/server"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: oblique <keygen|server|client> [-c config.json]")
		os.Exit(1)
	}

	subcmd := os.Args[1]
	fs := flag.NewFlagSet(subcmd, flag.ExitOnError)
	cfgPath := fs.String("c", "config.json", "path to json config")
	_ = fs.Parse(os.Args[2:])

	switch subcmd {
	case "keygen":
		priv, pub, psk, err := protocol.GenerateKeyPair()
		if err != nil {
			log.Fatal(err)
		}
		fmt.Printf("PrivateKey (server only): %s\n", priv)
		fmt.Printf("PublicKey  (client):      %s\n", pub)
		fmt.Printf("PSK        (both):        %s\n", psk)

	case "server":
		raw, err := os.ReadFile(*cfgPath)
		if err != nil {
			log.Fatal(err)
		}
		var cfg server.Config
		if err := json.Unmarshal(raw, &cfg); err != nil {
			log.Fatal(err)
		}
		srv, err := server.New(cfg)
		if err != nil {
			log.Fatal(err)
		}
		log.Fatal(srv.Run())

	case "client":
		raw, err := os.ReadFile(*cfgPath)
		if err != nil {
			log.Fatal(err)
		}
		var cfg client.Config
		if err := json.Unmarshal(raw, &cfg); err != nil {
			log.Fatal(err)
		}
		cl, err := client.New(cfg)
		if err != nil {
			log.Fatal(err)
		}
		log.Fatal(cl.Run())

	default:
		fmt.Println("Unknown command. Use: keygen, server, client")
		os.Exit(1)
	}
}
