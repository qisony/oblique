package protocol

import (
	"bytes"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"math/big"
	"sync"
)

const (
	FrameOpen  byte = 0x01
	FrameData  byte = 0x02
	FrameClose byte = 0x03
	FramePad   byte = 0x04
	FramePing  byte = 0x05

	MaxFrameData = 16384
)

type Frame struct {
	Type     byte
	StreamID uint32
	Payload  []byte
}

func EncodeFrame(f Frame) []byte {
	switch f.Type {
	case FrameOpen, FrameData:
		buf := make([]byte, 1+4+2+len(f.Payload))
		buf[0] = f.Type
		binary.BigEndian.PutUint32(buf[1:5], f.StreamID)
		binary.BigEndian.PutUint16(buf[5:7], uint16(len(f.Payload)))
		copy(buf[7:], f.Payload)
		return buf
	case FrameClose:
		buf := make([]byte, 1+4)
		buf[0] = f.Type
		binary.BigEndian.PutUint32(buf[1:5], f.StreamID)
		return buf
	case FramePad:
		buf := make([]byte, 1+2+len(f.Payload))
		buf[0] = f.Type
		binary.BigEndian.PutUint16(buf[1:3], uint16(len(f.Payload)))
		copy(buf[3:], f.Payload)
		return buf
	case FramePing:
		return []byte{FramePing}
	default:
		return nil
	}
}

func DecodeFrames(recordPlain []byte) ([]Frame, error) {
	var frames []Frame
	r := bytes.NewReader(recordPlain)
	for r.Len() > 0 {
		t, err := r.ReadByte()
		if err != nil {
			return nil, err
		}
		switch t {
		case FrameOpen, FrameData:
			var hdr [6]byte
			if _, err := r.Read(hdr[:]); err != nil {
				return nil, errors.New("truncated frame header")
			}
			sid := binary.BigEndian.Uint32(hdr[0:4])
			plen := int(binary.BigEndian.Uint16(hdr[4:6]))
			if plen > r.Len() {
				return nil, errors.New("truncated frame payload")
			}
			payload := make([]byte, plen)
			if plen > 0 {
				if _, err := r.Read(payload); err != nil {
					return nil, err
				}
			}
			frames = append(frames, Frame{Type: t, StreamID: sid, Payload: payload})
		case FrameClose:
			var sidBuf [4]byte
			if _, err := r.Read(sidBuf[:]); err != nil {
				return nil, errors.New("truncated close frame")
			}
			frames = append(frames, Frame{
				Type:     FrameClose,
				StreamID: binary.BigEndian.Uint32(sidBuf[:]),
			})
		case FramePad:
			var lBuf [2]byte
			if _, err := r.Read(lBuf[:]); err != nil {
				return nil, errors.New("truncated pad frame")
			}
			plen := int(binary.BigEndian.Uint16(lBuf[:]))
			if plen > r.Len() {
				return nil, errors.New("truncated pad payload")
			}
			if plen > 0 {
				_, _ = r.Seek(int64(plen), 1)
			}
		case FramePing:
			frames = append(frames, Frame{Type: FramePing})
		default:
			return nil, errors.New("unknown frame type")
		}
	}
	return frames, nil
}

// Shaper реализует корзинное выравнивание (PEDS) с окном HMW и бюджетом паддинга beta.
type Shaper struct {
	mu           sync.Mutex
	beta         float64
	padCredit    float64
	recordsSent  uint64
	bins         []int
	hmwThreshold uint64
}

func NewShaper(beta float64) *Shaper {
	if beta < 0 {
		beta = 0
	}
	return &Shaper{
		beta:         beta,
		padCredit:    4096, // Стартовый кредит на первые записи (HMW)
		bins:         []int{128, 256, 384, 512, 768, 1024, 1360, 2048, 4096, 8192, 16384},
		hmwThreshold: 8,
	}
}

func randInt(max int) int {
	if max <= 1 {
		return 0
	}
	n, err := rand.Int(rand.Reader, big.NewInt(int64(max)))
	if err != nil {
		return 0
	}
	return int(n.Int64())
}

// ShapePayload добавляет FRAME_PAD к полезным фреймам в соответствии с профилем и бюджетом.
func (s *Shaper) ShapePayload(rawFrames []byte) []byte {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.recordsSent++
	dataLen := len(rawFrames)
	s.padCredit += s.beta * float64(dataLen)
	if s.padCredit > 16384 {
		s.padCredit = 16384
	}

	// В режиме bulk (крупные пакеты >= 8 КБ) после окна HMW паддинг не добавляем
	if s.recordsSent > s.hmwThreshold && dataLen >= 8192 {
		return rawFrames
	}

	target := 0
	for _, b := range s.bins {
		if b >= dataLen+3 {
			target = b
			break
		}
	}
	// В окне маскировки хендшейка (первые 8 записей) добавляем разброс по соседней корзине
	if s.recordsSent <= s.hmwThreshold && target > 0 && target < 2048 {
		target += randInt(256)
	}

	padNeeded := target - dataLen - 3
	if padNeeded <= 0 {
		return rawFrames
	}
	if float64(padNeeded) > s.padCredit {
		padNeeded = int(s.padCredit)
	}
	if padNeeded <= 0 || dataLen+3+padNeeded > 32000 {
		return rawFrames
	}

	s.padCredit -= float64(padNeeded)
	padBytes := make([]byte, padNeeded)
	_, _ = rand.Read(padBytes)

	padFrame := EncodeFrame(Frame{Type: FramePad, Payload: padBytes})
	out := make([]byte, len(rawFrames)+len(padFrame))
	copy(out, rawFrames)
	copy(out[len(rawFrames):], padFrame)
	return out
}
