package protocol

import (
	"crypto/ecdh"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"sync"
	"time"

	"golang.org/x/crypto/chacha20"
	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/hkdf"
)

const (
	DirDownlink byte = 0x01
	DirUplink   byte = 0x02

	HeaderSize       = 11
	TagSize          = chacha20poly1305.Overhead // 16
	MaxRecordCTLen   = 32768 + TagSize
	AuthWindowSec    = 60
	TLSExporterLabel = "EXPORTER-oblique-v1"
)

var (
	ErrAuthFailed   = errors.New("authentication failed")
	ErrReplay       = errors.New("replay detected")
	ErrBadRecord    = errors.New("malformed or tampered record")
	ErrStreamClosed = errors.New("record stream closed")
)

type AuthPayload struct {
	Timestamp   int64
	AuthNonce   [12]byte
	SessionID   [16]byte
	SessionSeed [32]byte
	Direction   byte
	CarrierGen  uint32
}

type ReplayCache struct {
	mu      sync.Mutex
	entries map[[12]byte]int64
	lastGC  int64
}

func NewReplayCache() *ReplayCache {
	return &ReplayCache{
		entries: make(map[[12]byte]int64),
		lastGC:  time.Now().Unix(),
	}
}

func (rc *ReplayCache) CheckAndAdd(nonce [12]byte, now int64) bool {
	rc.mu.Lock()
	defer rc.mu.Unlock()

	if now-rc.lastGC > 30 {
		cutoff := now - (AuthWindowSec * 3)
		for k, ts := range rc.entries {
			if ts < cutoff {
				delete(rc.entries, k)
			}
		}
		rc.lastGC = now
	}
	if _, exists := rc.entries[nonce]; exists {
		return false
	}
	rc.entries[nonce] = now
	return true
}

func GenerateKeyPair() (privB64, pubB64, pskB64 string, err error) {
	priv, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		return "", "", "", err
	}
	psk := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, psk); err != nil {
		return "", "", "", err
	}
	return base64.RawURLEncoding.EncodeToString(priv.Bytes()),
		base64.RawURLEncoding.EncodeToString(priv.PublicKey().Bytes()),
		base64.RawURLEncoding.EncodeToString(psk),
		nil
}

func ExportTLSBinding(cs *tls.ConnectionState) ([]byte, error) {
	if cs == nil || !cs.HandshakeComplete {
		return nil, nil
	}
	return cs.ExportKeyingMaterial(TLSExporterLabel, nil, 32)
}

func deriveAuthKey(sharedSecret, psk, tlsBinding []byte) ([]byte, error) {
	ikm := make([]byte, 0, len(sharedSecret)+len(psk))
	ikm = append(ikm, sharedSecret...)
	ikm = append(ikm, psk...)

	r := hkdf.New(sha256.New, ikm, tlsBinding, []byte("oblique-v1-auth"))
	key := make([]byte, chacha20poly1305.KeySize)
	if _, err := io.ReadFull(r, key); err != nil {
		return nil, err
	}
	return key, nil
}

// SealAuthToken формирует base64url токен для HTTP-заголовка Cookie/Header.
// Формат: EphPub(32B) || AuthNonce(12B) || Ciphertext(61B + 16B Tag) = 121 байт.
func SealAuthToken(serverPubBytes, psk, tlsBinding []byte, ap AuthPayload, aad []byte) (string, error) {
	serverPub, err := ecdh.X25519().NewPublicKey(serverPubBytes)
	if err != nil {
		return "", err
	}
	ephPriv, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		return "", err
	}
	shared, err := ephPriv.ECDH(serverPub)
	if err != nil {
		return "", err
	}
	authKey, err := deriveAuthKey(shared, psk, tlsBinding)
	if err != nil {
		return "", err
	}
	aead, err := chacha20poly1305.New(authKey)
	if err != nil {
		return "", err
	}

	plain := make([]byte, 61)
	binary.BigEndian.PutUint64(plain[0:8], uint64(ap.Timestamp))
	copy(plain[8:24], ap.SessionID[:])
	copy(plain[24:56], ap.SessionSeed[:])
	plain[56] = ap.Direction
	binary.BigEndian.PutUint32(plain[57:61], ap.CarrierGen)

	ct := aead.Seal(nil, ap.AuthNonce[:], plain, aad)

	raw := make([]byte, 0, 32+12+len(ct))
	raw = append(raw, ephPriv.PublicKey().Bytes()...)
	raw = append(raw, ap.AuthNonce[:]...)
	raw = append(raw, ct...)
	return base64.RawURLEncoding.EncodeToString(raw), nil
}

func OpenAuthToken(token string, serverPriv *ecdh.PrivateKey, psk, tlsBinding, aad []byte, rc *ReplayCache) (AuthPayload, error) {
	var ap AuthPayload
	raw, err := base64.RawURLEncoding.DecodeString(token)
	if err != nil || len(raw) != 32+12+61+TagSize {
		return ap, ErrAuthFailed
	}

	ephPub, err := ecdh.X25519().NewPublicKey(raw[0:32])
	if err != nil {
		return ap, ErrAuthFailed
	}
	copy(ap.AuthNonce[:], raw[32:44])
	ct := raw[44:]

	shared, err := serverPriv.ECDH(ephPub)
	if err != nil {
		return ap, ErrAuthFailed
	}
	authKey, err := deriveAuthKey(shared, psk, tlsBinding)
	if err != nil {
		return ap, ErrAuthFailed
	}
	aead, err := chacha20poly1305.New(authKey)
	if err != nil {
		return ap, ErrAuthFailed
	}

	plain, err := aead.Open(nil, ap.AuthNonce[:], ct, aad)
	if err != nil || len(plain) != 61 {
		return ap, ErrAuthFailed
	}

	ap.Timestamp = int64(binary.BigEndian.Uint64(plain[0:8]))
	now := time.Now().Unix()
	diff := now - ap.Timestamp
	if diff < -AuthWindowSec || diff > AuthWindowSec {
		return ap, ErrAuthFailed
	}
	if rc != nil && !rc.CheckAndAdd(ap.AuthNonce, now) {
		return ap, ErrReplay
	}

	copy(ap.SessionID[:], plain[8:24])
	copy(ap.SessionSeed[:], plain[24:56])
	ap.Direction = plain[56]
	ap.CarrierGen = binary.BigEndian.Uint32(plain[57:61])
	return ap, nil
}

type RecordCipher struct {
	aead   interface {
		Seal(dst, nonce, plaintext, additionalData []byte) []byte
		Open(dst, nonce, ciphertext, additionalData []byte) ([]byte, error)
	}
	hpKey []byte
	seq   uint64
	mu    sync.Mutex
}

func NewRecordCipher(sessionSeed [32]byte, sessionID [16]byte, dir byte, carrierGen uint32) (*RecordCipher, error) {
	info := make([]byte, 0, 32)
	info = append(info, []byte("oblique-v1-rec-")...)
	info = append(info, dir)
	var genBuf [4]byte
	binary.BigEndian.PutUint32(genBuf[:], carrierGen)
	info = append(info, genBuf[:]...)

	r := hkdf.New(sha256.New, sessionSeed[:], sessionID[:], info)
	aeadKey := make([]byte, chacha20poly1305.KeySize)
	hpKey := make([]byte, chacha20.KeySize)
	if _, err := io.ReadFull(r, aeadKey); err != nil {
		return nil, err
	}
	if _, err := io.ReadFull(r, hpKey); err != nil {
		return nil, err
	}
	aead, err := chacha20poly1305.New(aeadKey)
	if err != nil {
		return nil, err
	}
	return &RecordCipher{
		aead:  aead,
		hpKey: hpKey,
	}, nil
}

func applyHPMask(hpKey, sample, hdr []byte) error {
	if len(sample) < 16 || len(hdr) != HeaderSize {
		return ErrBadRecord
	}
	ctr := binary.LittleEndian.Uint32(sample[0:4])
	nonce := sample[4:16]
	c, err := chacha20.NewUnauthenticatedCipher(hpKey, nonce)
	if err != nil {
		return err
	}
	c.SetCounter(ctr)
	c.XORKeyStream(hdr, hdr)
	return nil
}

// WriteRecord кодирует запись: MaskedHDR(11B) || Ciphertext+Tag (>=16B).
func (rc *RecordCipher) WriteRecord(w io.Writer, flags byte, plaintext []byte) (int, error) {
	rc.mu.Lock()
	defer rc.mu.Unlock()

	if len(plaintext)+TagSize > MaxRecordCTLen {
		return 0, fmt.Errorf("plaintext too large: %d", len(plaintext))
	}

	seq := rc.seq
	rc.seq++

	var nonce [12]byte
	binary.BigEndian.PutUint64(nonce[4:12], seq)

	ctLen := uint16(len(plaintext) + TagSize)
	var hdr [HeaderSize]byte
	binary.BigEndian.PutUint64(hdr[0:8], seq)
	binary.BigEndian.PutUint16(hdr[8:10], ctLen)
	hdr[10] = flags

	ct := rc.aead.Seal(nil, nonce[:], plaintext, hdr[:])
	if len(ct) < 16 {
		return 0, ErrBadRecord
	}

	var maskedHdr [HeaderSize]byte
	copy(maskedHdr[:], hdr[:])
	if err := applyHPMask(rc.hpKey, ct[0:16], maskedHdr[:]); err != nil {
		return 0, err
	}

	out := make([]byte, HeaderSize+len(ct))
	copy(out[0:HeaderSize], maskedHdr[:])
	copy(out[HeaderSize:], ct)

	return w.Write(out)
}

// ReadRecord читает и проверяет одну замаскированную запись из потока.
func (rc *RecordCipher) ReadRecord(r io.Reader) (flags byte, plaintext []byte, err error) {
	var hdr [HeaderSize]byte
	if _, err = io.ReadFull(r, hdr[:]); err != nil {
		return 0, nil, err
	}
	var sample [16]byte
	if _, err = io.ReadFull(r, sample[:]); err != nil {
		return 0, nil, err
	}

	if err = applyHPMask(rc.hpKey, sample[:], hdr[:]); err != nil {
		return 0, nil, err
	}

	seq := binary.BigEndian.Uint64(hdr[0:8])
	ctLen := int(binary.BigEndian.Uint16(hdr[8:10]))
	flags = hdr[10]

	if ctLen < TagSize || ctLen > MaxRecordCTLen {
		return 0, nil, ErrBadRecord
	}

	ct := make([]byte, ctLen)
	copy(ct[0:16], sample[:])
	if ctLen > 16 {
		if _, err = io.ReadFull(r, ct[16:]); err != nil {
			return 0, nil, err
		}
	}

	var nonce [12]byte
	binary.BigEndian.PutUint64(nonce[4:12], seq)

	plaintext, err = rc.aead.Open(nil, nonce[:], ct, hdr[:])
	if err != nil {
		return 0, nil, ErrBadRecord
	}
	return flags, plaintext, nil
}
